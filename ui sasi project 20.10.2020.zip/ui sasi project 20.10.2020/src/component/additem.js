import React,{Component} from 'react';
import './css/additem.css'

import { AppBar, Typography,CardActionArea,CardMedia,Paper,Divider,Link } from '@material-ui/core';
import { Card, CardContent, Grid, FormControl, TextField, InputLabel, OutlinedInput, Pape, Box,Select, Button,CardActions , TextareaAutosize , FormHelperText } from '@material-ui/core';
import InsertPhotoOutlinedIcon from '@material-ui/icons/InsertPhotoOutlined';
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';

import AddImg from './images/add.png';

import ApiService from "./../ApiService";



class AddItem extends Component {
    constructor(props){
      super(props)
      this.state={
        message:'',

        shopId:localStorage.getItem("ShopId"),
        productTitle:'',
        category:'',
        productDescription:'',
        productBrand:'',
        productModel:'',
        lastPrice:'',
        salePrice:'',
        warranty:'',
        rating:'',
        stock:'',

        sts:'',

        file1: '',
        imagePreviewUrl1: '',

        file2: '',
        imagePreviewUrl2: '',

        file3: '',
        imagePreviewUrl3: '',

        file4: '',
        imagePreviewUrl4: '',

        file5: '',
        imagePreviewUrl5: '',


        message :"",
        severity:"",
        alertTitle:"",

      }
    }

    onChange = (e) =>{
        this.setState({[e.target.name]:e.target.value,})
    }




    onChangeProductTitle = (e) =>{
        this.setState({
          productTitle:e.target.value,
        })
    }

  _handleImg1Submit(e) {
    e.preventDefault();
    // TODO: do something with -> this.state.file
    console.log('handle uploading-', this.state.file1);
  }





  _handleImage1Change1(e) {
    e.preventDefault();

    let reader1 = new FileReader();
    let file1 = e.target.files[0];
    // console.warn("Img data",file1);
    const formData = {file:e.target.result}
    reader1.onloadend = (e) => {
      this.setState({
        file1: file1,
        imagePreviewUrl1: reader1.result,
        sts:formData,

      });
      // console.warn("img ",reader1.result);
       // console.warn("img2 ",e.target.result);
       const formData2 = {file:e.target.result}
      console.warn(formData2);
      const formData3 = e.target.result;
      console.warn(formData3);
    }

    // reader1.onloadend = (e) => {
    //   console.warn("Img data",e.target.result);
    // }

    reader1.readAsDataURL(file1)
  }



  _handleImage1Change2(e) {
    e.preventDefault();

    let reader2 = new FileReader();
    let file2 = e.target.files[0];

    reader2.onloadend = () => {
      this.setState({
        file2: file2,
        imagePreviewUrl2: reader2.result
      });
    }

    reader2.readAsDataURL(file2)
  }


  _handleImage1Change3(e) {
    e.preventDefault();

    let reader3 = new FileReader();
    let file3 = e.target.files[0];

    reader3.onloadend = () => {
      this.setState({
        file3: file3,
        imagePreviewUrl3: reader3.result
      });
    }

    reader3.readAsDataURL(file3)
  }


  _handleImage1Change4(e) {
    e.preventDefault();

    let reader4 = new FileReader();
    let file4 = e.target.files[0];

    reader4.onloadend = () => {
      this.setState({
        file4: file4,
        imagePreviewUrl4: reader4.result
      });
    }

    reader4.readAsDataURL(file4)
  }


  _handleImage1Change5(e) {
    e.preventDefault();

    let reader5 = new FileReader();
    let file5 = e.target.files[0];

    reader5.onloadend = () => {
      this.setState({
        file5: file5,
        imagePreviewUrl5: reader5.result
      });
    }

    reader5.readAsDataURL(file5)
  }


  handleChangCategorye = (e) =>{
    this.setState ({
      category:e.target.value
    });
  }



  addProductFormSubmit = () =>{
    let product = {
        shopId: this.state.shopId,
        title: this.state.productTitle,
        description: this.state.productDescription,
        lastPrice:this.state.lastPrice,
        sellPrice:this.state.salePrice,
        warranty:this.state.warranty,
        stock:this.state.stock,
        brand:this.state.productBrand,
        model:this.state.productModel,
        category:this.state.category,


        image1:this.state.imagePreviewUrl1,
        image2:this.state.imagePreviewUrl2,
        image3:this.state.imagePreviewUrl3,
        image4:this.state.imagePreviewUrl4,
        image5:this.state.imagePreviewUrl5,

    };



        ApiService.addProduct(product)
        .then((res) => {
            this.setState({
                message : 'Product added successfully.',
                severity:"success",
                alertTitle:"Success",
            });


            setTimeout(() => {
                this.props.history.push('/shop/'+this.state.shopId)
            },2500)

        })
        .catch(error => {
            this.setState({
                message : 'User details  Update failed.',
                severity:"error",
                alertTitle:"failed",
            });
            setTimeout(() => {
                this.setState({message:""});
            },2500);
        })

    }






  render(){
    let {imagePreviewUrl1} = this.state;
    let {imagePreviewUrl2} = this.state;
    let {imagePreviewUrl3} = this.state;
    let {imagePreviewUrl4} = this.state;
    let {imagePreviewUrl5} = this.state;




    //this is product brand list const

    const productBrandList = [
      {
        title:"Apple"
      },
      {
        title:"Samsung"
      },
      {
        title:"Realmi"
      },
      {
        title:"OnePlus"
      },
      {
        title:"Vivo"
      },
    ];


    return(
      <div>
        {this.state.message&&(
          <div>
              <Alert variant="filled" severity={this.state.severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                    <AlertTitle>{this.state.alertTitle}</AlertTitle>
                    {this.state.message}
              </Alert>
          </div>
        )}

        <Paper id="addProductMainDiv">



            <Typography variant="h4" style={{textAlign:'center'}}>Add Product</Typography>
            <ValidatorForm onSubmit={this.addProductFormSubmit} >
            <Grid container>

              <Grid item xs={12} sm={12} md={6}>
                <Paper elevation={3} id="productTitleDiv">
                      <Typography variant="h5" id="producTitleText">Product Title</Typography>


                      <TextValidator
                          Id='productTitleIp'
                          variant="outlined"
                          label="Product Title"
                          onChange={this.onChange}
                          name="productTitle"
                          value={this.state.productTitle}
                          validators={['required']}
                          errorMessages={["Please fill this field"]}
                      />
                </Paper>
              </Grid>

              <Grid item xs={12} sm={12} md={6}>
                <Paper elevation={3} id="productCategoryDiv">
                      <Typography variant="h5" id="producCategoryText">Product Category</Typography>
                      <FormControl variant="outlined" id='sortSelectIp'>
                            <InputLabel htmlFor="outlined-category-native-simple">Category</InputLabel>
                            <Select
                                  native
                                  value={this.state.category}
                                  onChange={this.handleChangCategorye}
                                  label="Category"
                                  validators={['required']}
                                  errorMessages={["Please fill this field"]}

                            >
                                  <option value={''}></option>
                                  <option value={'Mobile And Tablets'}>Mobile And Tablets</option>
                                  <option value={'Mobile And Tablets Accessories'}>Mobile And Tablets Accessories</option>
                                  <option value={'Computers & Labtops'}>Computers & Labtops</option>
                                  <option value={'Computers & Labtops Accessories'}>Computers & Labtops Accessories</option>
                                  <option value={'Cameras'}>Cameras</option>
                                  <option value={'Cameras Accessories'}>Cameras Accessories</option>
                                  <option value={'TV , Video & Audio'}>TV , Video & Audio</option>

                            </Select>
                      </FormControl>

                </Paper>
              </Grid>

              <Grid item xs={12} sm={12} md={6}>
                <Paper elevation={3} id="productImageInputDiv">
                    <Typography variant="h5" id="producImageText">Product Images</Typography>
                    <div className="previewComponent">
                      <form onSubmit={(e)=>this._handleImg1Submit(e)}>
                          <Grid container>
                                <Grid xs={12}>

                                      <div id="imgPreview1">
                                          <input className="fileInput1"
                                            type="file"
                                            accept="image/*"
                                            onChange={(e)=>this._handleImage1Change1(e)}
                                           />

                                           {!imagePreviewUrl1&&(
                                              <img src={AddImg} className="addItemImg1" />
                                            )}
                                              <img src={imagePreviewUrl1} className="addItemImg1" />

                                      </div>

                                    {this.state.file1&&(
                                      <div id="imgPreview2">
                                          <input className="fileInput2"
                                            type="file"
                                            accept="image/*"
                                            onChange={(e)=>this._handleImage1Change2(e)}
                                          />

                                          {!imagePreviewUrl2&&(
                                             <img src={AddImg} className="addItemImg2" />
                                           )}

                                          <img src={imagePreviewUrl2} className="addItemImg2" />
                                      </div>
                                    )}

                                    {this.state.file2&&(
                                      <div id="imgPreview3">
                                          <input className="fileInput3"
                                            type="file"
                                            accept="image/*"
                                            onChange={(e)=>this._handleImage1Change3(e)}
                                          />

                                          {!imagePreviewUrl3&&(
                                             <img src={AddImg} className="addItemImg3" />
                                           )}

                                          <img src={imagePreviewUrl3} className="addItemImg3" />
                                      </div>
                                    )}

                                    {this.state.file3&&(
                                      <div id="imgPreview4">
                                          <input className="fileInput4"
                                            type="file"
                                            accept="image/*"
                                            onChange={(e)=>this._handleImage1Change4(e)}
                                          />

                                          {!imagePreviewUrl4&&(
                                             <img src={AddImg} className="addItemImg4" />
                                           )}

                                          <img src={imagePreviewUrl4} className="addItemImg4" />
                                      </div>
                                    )}
                                    {this.state.file4&&(
                                      <div id="imgPreview5">
                                          <input className="fileInput5"
                                            type="file"
                                            accept="image/*"
                                            onChange={(e)=>this._handleImage1Change5(e)}
                                          />

                                          {!imagePreviewUrl5&&(
                                             <img src={AddImg} className="addItemImg5" />
                                           )}

                                          <img src={imagePreviewUrl5} className="addItemImg5" />
                                      </div>
                                    )}
                                </Grid>
                          </Grid>

                      </form>
                    </div>
                </Paper>
              </Grid>

              <Grid item xs={12} sm={12} md={6}>
                <Paper elevation={3} id="productDescriptionDiv">
                      <Typography variant="h5" id="producCategoryText">Product Description</Typography>
                      <textarea aria-label="minimum height" rowsMin={3} placeholder="Minimum 3 rows" id="productDesId" name="productDescription" value={this.state.productDescription} onChange={this.onChange} />
                </Paper>
              </Grid>

              <Grid item xs={12} sm={12} md={6}>
                <Paper elevation={3} id="productBrandDiv">
                      <Typography variant="h5" id="producCategoryText">Product Brand</Typography>

                      <TextValidator
                          Id='productBrandIP'
                          variant="outlined"
                          label="Product Brand"
                          onChange={this.onChange}
                          name="productBrand"
                          value={this.state.productBrand}
                          validators={['required']}
                          errorMessages={["Please fill this field"]}
                      />


                </Paper>
              </Grid>

              <Grid item xs={12} sm={12} md={6}>
                <Paper elevation={3} id="productModelDiv">
                      <Typography variant="h5" id="producCategoryText">Product Model</Typography>

                      <TextValidator
                          Id='productModelIP'
                          variant="outlined"
                          label="Product Model"
                          onChange={this.onChange}
                          name="productModel"
                          value={this.state.productModel}
                          validators={['required']}
                          errorMessages={["Please fill this field"]}
                      />

                </Paper>
              </Grid>

              <Grid item xs={12} sm={12} md={6}>
                <Paper elevation={3} id="productLastPriceDiv">
                      <Typography variant="h5" id="producCategoryText">Stock</Typography>

                      <TextValidator
                          Id='productLastPriceIP'
                          variant="outlined"
                          label="Stock"
                          onChange={this.onChange}
                          name="stock"
                          value={this.state.stock}
                          validators={['required']}
                          errorMessages={["Please fill this field"]}
                          type="number"
                      />

                </Paper>
              </Grid>

              <Grid item xs={12} sm={12} md={6}>
                <Paper elevation={3} id="productLastPriceDiv">
                      <Typography variant="h5" id="producCategoryText">Last Price (Rs) (Optional)</Typography>

                      <TextValidator
                          Id='productLastPriceIP'
                          variant="outlined"
                          label="Last Price"
                          onChange={this.onChange}
                          name="lastPrice"
                          value={this.state.lastPrice}
                          // validators={['required']}
                          // errorMessages={["Please fill this field"]}
                          type="number"
                      />

                </Paper>
              </Grid>


              <Grid item xs={12} sm={12} md={6}>
                <Paper elevation={3} id="productSalePriceDiv">
                      <Typography variant="h5" id="producCategoryText">Sale Price (Rs) </Typography>


                      <TextValidator
                          Id='productSalePriceIP'
                          variant="outlined"
                          label="Sale Price"
                          onChange={this.onChange}
                          name="salePrice"
                          value={this.state.salePrice}
                          validators={['required']}
                          errorMessages={["Please fill this field"]}
                          type="number"
                      />

                </Paper>
              </Grid>


              <Grid item xs={12} sm={12} md={6}>
                <Paper elevation={3} id="productWarrantyDiv">
                      <Typography variant="h5" id="producCategoryText">Warranty (Months)</Typography>


                      <TextValidator
                          Id='productWarrantyIP'
                          variant="outlined"
                          label="Warranty"
                          onChange={this.onChange}
                          name="warranty"
                          value={this.state.warranty}
                          validators={['required']}
                          errorMessages={["Please fill this field"]}
                          type="number"
                      />
                </Paper>
              </Grid>


            </Grid>
            <br/><br/>

                  <Box id="addProductDiv">
                      <Button id="addProductBtn" type="submit"  >Add Product</Button>
                  </Box>

              <br/><br/><br/>
          </ValidatorForm>

      </Paper>
    </div>
    );
  }
}

export default AddItem;
