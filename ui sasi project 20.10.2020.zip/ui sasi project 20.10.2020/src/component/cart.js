import React, { Component } from 'react'
import {DataContext} from '../component/Data'
import {Link} from 'react-router-dom'
import './css/cart.css'
import {Grid,Paper,Card,CardContent,Typography,Button, CardActions,CardMedia,CardActionArea,Box} from '@material-ui/core';

export  class Cart extends Component {
    static contextType = DataContext;

    componentDidMount(){
        this.context.getTotal();
    }

    render() {
        const {cart,increase,reduction,removeProduct,total} = this.context;

        if(cart.length === 0){
            return <h2 style={{textAlign:"center"}}>Nothings Product</h2>
        }else{
            return (
                <div className= "fullBox" >


                    <Grid container>



                        {
                            cart.map(item =>(
                                <Grid item xs={12} sm={12} md={12} lg={12}>

                                      <div className="details" key={item.productId}>
                                            <button className="delete" onClick={() => removeProduct(item.productId)}>X</button>
                                            <Grid container>
                                                <Grid item xs={12} sm={6} md={6} lg={6}>
                                                  <Paper elevation='5' style={{margin:'auto',marginBottom:'35px',width:'90%',}}>
                                                    <img src={item.image1} alt=""/>
                                                  </Paper>
                                                </Grid>
                                                <Grid item xs={12} sm={6} md={6} lg={6}>

                                                    <div className="box">
                                                        <div className="row">
                                                            <h3>{item.title}</h3>
                                                        </div>
                                                        <p>{item.description}</p>
                                                        <div className="amount">
                                                            <h4> {item.sellPrice}*{item.quantity}=  Rs{item.sellPrice * item.quantity}</h4><br/>

                                                            <button className="count" onClick={() => increase(item.productId)}> + </button>
                                                            <span>{item.quantity}</span>
                                                            <button className="count" onClick={() => reduction(item.productId)}> - </button>
                                                        </div>
                                                    </div>

                                                </Grid>

                                            </Grid>
                                      </div>
                                </Grid>
                            ))
                        }
                    </Grid>
                    <div className="total">
                        <Link to="/payment">Buy all item</Link>
                        <h3>Total: Rs. {total}.00</h3>
                    </div>

                </div>
                )
            }
    }
}

export default Cart;
