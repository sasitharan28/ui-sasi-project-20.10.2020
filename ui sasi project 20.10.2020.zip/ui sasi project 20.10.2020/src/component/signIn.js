import React, { Component } from 'react';

import {Paper,CardContent,Typography,Button} from '@material-ui/core';
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';

import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';

import './css/signin.css';
import ApiService from "./../ApiService";

class SignIn extends Component {
    constructor(props){
        super(props)
        this.state = {
            username: "",
            password: "",
            message: "",
            loginSucces:false,
            roles:[],
        };
    }

          onChangeUsername = (e) => {
            this.setState({
              username: e.target.value
            });
          }

          onChangePassword = (e) => {
            this.setState({
              password: e.target.value
            });
          }

        handleLogin = (event) => {
            event.preventDefault();
            let regis = {
                userName : this.state.username,
                password : this.state.password
            }
            ApiService.login(regis)
            .then((res) =>{
                // console.log(res.data);
                localStorage.setItem("user",res.data);
                localStorage.setItem("userId",res.data.id);
                localStorage.setItem("userName",res.data.username);
                localStorage.setItem("roles",res.data.roles);


                if(localStorage.getItem("roles").includes("ADDMIN_ROLE")){
                    localStorage.setItem("admin",true);
                }


                // this.setRoles(res.data.roles)

                this.setState({
                  message:"Signin success",
                  severity:'success',
                  AlertTitle:'Success',


                })

                setTimeout(() => {
                    this.props.history.push("/home")
                    window.location.reload();
                    this.setState({message:""})
                },2500);

                 this.getShopInfo()


            })
            .catch(err => {
                this.setState({
                  message:"user name or password invalid",
                  severity:'error',
                  AlertTitle:'Failed',
                })
                setTimeout(() => {
                    this.setState({message:""})
                },2500);
            })

        }

        getShopInfo = () => {
            ApiService.getShopByUserId(localStorage.getItem("userId"))
            .then((res) => {
              localStorage.setItem("shopId",res.data.shopId);
              console.log( "ShopId :-" + localStorage.getItem("shopId"))
            })


        }

        // loadUser = () => {
        //   ApiService.getUserById(localStorage.getItem("userId"))
        //   .then(res => {
        //       // this.setState({
        //       //   roles:res.data.roles,
        //       // })
        //       if(res.data){
        //         {res.data.roles.map( role => (
        //
        //             this.setState(prevState => ({
        //               roles: [...prevState.roles,
        //                   role.name,
        //               ]
        //             }))
        //         ))}
        //
        //         this.setRoles()
        //       }
        //   })
        // }
        //
        //
        //
        // setRoles = () => {
        //
        //     localStorage.setItem("roles",this.state.roles);
        //     if(this.state.roles.includes("ADDMIN_ROLE")){
        //
        //         localStorage.setItem("admin",true);
        //     }else {
        //
        //         localStorage.setItem("admin",false);
        //     }
        //
        // }





    render() {

        return(
          <div >
          {this.state.message&&(
            <div>
                <Alert variant="filled" severity={this.state.severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                      <AlertTitle>{this.state.AlertTitle}</AlertTitle>
                      {this.state.message}
                </Alert>

            </div>
          )}
                <Paper id="signInCard">



                    <CardContent>
                        <ValidatorForm onSubmit={this.handleLogin} >
                            <Typography variant='h3' id="signinTitle">
                                Login to IBaseShop
                            </Typography>
                            <br/>

                            <TextValidator
                                helperText="Please enter username"
                                variant="outlined"
                                label="Username"
                                onChange={this.onChangeUsername}
                                name="Username"
                                value={this.state.username}
                                Id="signInIP1"
                                validators={['required']}
                                errorMessages={['this field is required']}
                            />

                            <br/><br/>

                            <TextValidator
                                helperText="Please enter password"
                                variant="outlined"
                                label="Password"
                                onChange={this.onChangePassword}
                                name="Password"
                                value={this.state.password}
                                id="signInIP2"
                                validators={['required']}
                                errorMessages={['this field is required']}
                                type="password"

                            />

                            <br/><br/>

                            <Button variant="contained" id="signinBtn" type="submit"  >
                                LOG IN
                            </Button>

                            <p>To Register click  <a href='/signup'>here</a></p>

                        </ValidatorForm>
                  </CardContent>
              </Paper>
          </div>

        )
    }
}
export default SignIn;
