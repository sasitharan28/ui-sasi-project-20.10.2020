import React, { Component } from 'react'

import ApiService from "./../ApiService";
import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';
import {Grid,Paper,Card,CardContent,Typography,Button, CardActions,CardMedia,CardActionArea} from '@material-ui/core';

export const DataContext = React.createContext();


//

export class Data extends Component {
  constructor(props){
    super(props)
    this.state={
      products:[],
      cart: [],
      total: 0,
      payment:[],
      cartNo:0,
      buyProductDetails:[],
      tt:["st","tt","rt","vt"],
    }
  }






    addCart = (id) =>{
        const {cart,cartNo} = this.state;
        const check = cart.every(item =>{
            return item.productId !== id
        })
        if(check){
            // const data = products.filter(product =>{
            //     return product.productId === id
            // })
            ApiService.getProductById(id)
            .then(res =>{
                const data = res.data;

                this.setState(prevState => ({
                  cart: [...prevState.cart, {

                    "productId": data.productId,
                    "shopId": data.shopId,
                    "title": data.title,
                    "lastPrice": data.lastPrice,
                    "sellPrice": data.sellPrice,
                    "warranty": data.warranty,
                    "rating": data.rating,
                    "stock": data.stock,
                    "brand": data.brand,
                    "model": data.model,
                    "category": data.category,
                    "date": data.date,
                    "image1": data.image1,
                    "quantity":1,

                    "buyProductId": data.productId,
                    "price": data.sellPrice,

                  }]
                }))


                this.setState(prevState => ({
                  buyProductDetails: [...prevState.buyProductDetails, {
                    "shopId": data.shopId,
                    "quantity":1,
                    "buyProductId": data.productId,
                    "price": data.sellPrice,

                  }]
                }))


                this.setState({
                    cartNo:cartNo+1,
                })

                this.getTotal();
                alert("This product has been aded")
                // <Alert
                //     action={
                //       <Button color="inherit" size="small">
                //         UNDO
                //       </Button>
                //     }
                //   >
                //     "This is a success alert — check it out!"
                //   </Alert>


                localStorage.setItem('dataCartNo', JSON.stringify(this.state.cartNo))
            })

        }else{
            alert("The product has been added to cart.")
        }
    };

    increase = id =>{
        const { cart } = this.state;
        cart.forEach(item =>{
            if(item.productId === id){
                item.quantity += 1;
            }
        })
        this.setState({cart: cart});
        this.getTotal();
    };

    reduction = id =>{
        const { cart } = this.state;
        cart.forEach(item =>{
            if(item.productId === id){
                item.quantity === 1 ? item.quantity = 1 : item.quantity -=1;
            }
        })
        this.setState({cart: cart});
        this.getTotal();
    };

    removeProduct = id =>{
        if(window.confirm("Do you want to delete this product?")){
            const {cart,cartNo} = this.state;
            cart.forEach((item1, index) =>{
                if(item1.productId === id){
                    cart.splice(index, 1)
                }
            })
            this.setState({cart: cart,cartNo:cartNo-1,});
            this.getTotal();
            localStorage.setItem('dataCartNo', JSON.stringify(this.state.cartNo))
        }
    };


    // getCartNo = () =>{
    //     const {cart} = this.state;
    //     const {cartNo} = 0;
    //     cart.map(row =>(
    //         cartNo+1
    //     ))
    //     this.setState({cartNo:cartNo,})
    // }

    /////////////////////////
    // remove2 = (id) =>{
    //     if(window.confirm("Do you want to delete this product?????????????")){
    //         const {payment} = this.state;
    //         payment.forEach((item2, index) =>{
    //             if(item2.productd === id){
    //                 payment.splice(index, 1)
    //             }
    //         })
    //         this.setState({payment: payment});
    //         this.getTotal();
    //     }
    // };
    /////////////

    getTotal = ()=>{
        const{cart} = this.state;
        const res = cart.reduce((prev, item) => {
            return prev + (item.sellPrice * item.quantity);
        },0)
        this.setState({total: res})

        // const tt = this.state;
        // const cartNo = tt.length;
        // this.setState({cartNo: cartNo})
        // alert(cartNo)
    };

    //////////////////////////////////////////////////////////////
    buythins =(id) =>{
        const {products, payment,cart} = this.state;
        const data = products.filter(product =>{
            return product.productId === id
        })
        // this.setState({payment: [...payment,...data]})
        this.setState({cart: [...cart,...data]})
        this.getTotal();
    }
    ////////////////////////////////////////////////////////////

    componentDidUpdate(){
        localStorage.setItem('dataCart', JSON.stringify(this.state.cart))
        localStorage.setItem('dataBuyProductDetails', JSON.stringify(this.state.buyProductDetails))

        localStorage.setItem('dataTotal', JSON.stringify(this.state.total))

        localStorage.setItem('dataBuythins', JSON.stringify(this.state.payment))
        localStorage.setItem('dataCartNo', JSON.stringify(this.state.cartNo))
    };

    componentDidMount(){
        const dataCart = JSON.parse(localStorage.getItem('dataCart'));
        if(dataCart !== null){
            this.setState({cart: dataCart});
        }
        const dataBuyProductDetails = JSON.parse(localStorage.getItem('dataBuyProductDetails'));
        if(dataBuyProductDetails !== null){
            this.setState({buyProductDetails: dataBuyProductDetails});
        }
        const dataTotal = JSON.parse(localStorage.getItem('dataTotal'));
        if(dataTotal !== null){
            this.setState({total: dataTotal});
        }
        const dataBuythins = JSON.parse(localStorage.getItem('dataBuythins'));
        if(dataBuythins !== null){
            this.setState({payment: dataBuythins});
        }
        const dataCartNo = JSON.parse(localStorage.getItem('dataCartNo'));
        if(dataCartNo !== null){
            this.setState({cartNo: dataCartNo});
        }
    }

    render() {
        const { cart,cartNo,total,shops,payment,buyProductDetails} = this.state;
        const {addCart,reduction,increase,removeProduct,getTotal,buythins,remove2} = this;
        return (
            <DataContext.Provider
            value={{addCart, cart , buyProductDetails , cartNo, reduction,increase,removeProduct,total,getTotal,shops,buythins,payment,remove2}}>
                {this.props.children}
            </DataContext.Provider>
        )
    }
}
