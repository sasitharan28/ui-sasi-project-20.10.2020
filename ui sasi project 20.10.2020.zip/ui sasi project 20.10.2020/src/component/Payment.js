import React, { Component } from 'react'

import {DataContext} from './Data'
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';

// import Input from '@material-ui/core/Input';
import TextField from '@material-ui/core/TextField';
import Box from '@material-ui/core/Box';

import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';
import ApiService from "./../ApiService";




import {Grid,Paper,Card,CardContent,Typography,Button, CardActions,CardMedia,CardActionArea} from '@material-ui/core';

import './css/Payment.css';
import BuyingThings from './BuyingThings';


export default class Payment extends Component {
    constructor(props){
      super(props)
      this.state={
        st:"",
        address:'',
        phone:'',
        user:[],
        email:'',
        userName:'',
        firstName:'',
        lastName:'',
        cart:[],
        buyProductDetails:[],
        total:1,

        message:'',
        severity:'',
        alertTitle:'',
      }
    }

    static contextType = DataContext;

    componentDidMount(){
        this.context.getTotal();
        this.setState({
            user:localStorage.getItem("user")
        })
        this.loadUser()
        const {total} = this.context;
        this.setState({
          total:total,
        })
        const {cart} = this.context;
        //
        {cart.map(row =>(
            this.setState(prevState => ({
                buyProductDetails: [...prevState.buyProductDetails, {
                    "buyProductId":row.productId,
                    "quantity":row.quantity,
                    "price":row.sellPrice,
                    "shopId":row.shopId,
                }]
            }))
        ))}

    }







    loadUser = () => {
      ApiService.viewUserById(localStorage.getItem("userId"))
          .then(res =>{
              this.setState({
                userName:res.data.userName,
                address:res.data.address,
                emil:res.data.email,
                phone:res.data.phoneNumber,
                firstName:res.data.firstName,
                lastName:res.data.lastName,
              })
          })

    }

    onChange = (e) => {
        this.setState({[e.target.name]: e.target.value})

    }



    putOrder = () => {
        alert(localStorage.getItem("dataBuyProductDetails"))
        // alert(this.state.total)
      const order = {
          userId:localStorage.getItem("userId"),
          buyProductDetails:localStorage.getItem("dataBuyProductDetails"),
          totalPrice:localStorage.getItem("dataTotal"),
      }
        ApiService.addOrder(order)
          .then(res => {
              this.setState({
                message:"Thank you for your purchase.",
                severity:'success',
                alertTitle:'Success',
              })
          })
          .catch(err =>{
              this.setState({
                  message:"Sorry please reload your page.",
                  severity:'error',
                  alertTitle:'Oh noo',
              })
          })
    }




    render() {

        const {total,cart,buyProductDetails} = this.context;

        return(
          <div>
          {this.state.message&&(
            <div>
                <Alert variant="filled" severity={this.state.severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                      <AlertTitle>{this.state.alertTitle}</AlertTitle>
                      {this.state.message}
                </Alert>
            </div>
          )}
            <Paper id="paper1">
                <div className="payment_d">
                <ValidatorForm ref="form" onSubmit={this.putOrder}>
                    <div className="heading">
                        <h2>Oder confirmation</h2>

                    </div>


                        <div className="boder">
                            <div className="detail_1">
                                <Grid container>
                                    <Grid item xs={12} md={6}>
                                        <Box className="box">
                                            <h3>Your Information</h3>
                                            <hr/>
                                            <TextValidator
                                                variant="outlined"
                                                label="First name"
                                                name="firstName"
                                                value={this.state.firstName}
                                                onChange={this.onChange}
                                                style={{width:'90%',display:'flex',margin:'auto',marginTop:'20px'}}
                                                validators={['required',]}
                                                errorMessages={['This field is required',]}
                                            />

                                            <TextValidator
                                                variant="outlined"
                                                label="Last name"
                                                name="lastName"
                                                value={this.state.lastName}
                                                onChange={this.onChange}
                                                style={{width:'90%',display:'flex',margin:'auto',marginTop:'20px'}}
                                                validators={['required',]}
                                                errorMessages={['This field is required',]}
                                            />

                                        </Box>
                                    </Grid>
                                    <Grid item xs={12} md={6}>
                                        <Box className="box">
                                            <h3>Shipping Address</h3>
                                            <hr/>
                                            <TextValidator
                                                variant="outlined"
                                                label="address"
                                                name="address"
                                                value={this.state.address}
                                                onChange={this.onChange}
                                                style={{width:'90%',display:'flex',margin:'auto',marginTop:'20px'}}
                                                validators={['required',]}
                                                errorMessages={['This field is required',]}
                                                multiline
                                                rows={4}
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item xs={12} md={6}>
                                        <Box className="box">
                                            <h3>Payment method</h3>
                                            <hr/>

                                            <RadioGroup aria-label="quiz" name="quiz" value="Cash On Delivery" style={{marginLeft:'5%'}} >
                                              <FormControlLabel value="Cash On Delivery" control={<Radio />} label="Cash On Delivery" cheked />
                                            </RadioGroup>
                                            {/* <input></input> */}
                                        </Box>
                                    </Grid>
                                    <Grid item xs={12} sm={6}>
                                        <Box className="box">
                                            <h3>Phone Number</h3>
                                            <hr/>
                                                <TextValidator
                                                    variant="outlined"
                                                    label="Phone number"
                                                    name="phone"
                                                    value={this.state.phone}
                                                    onChange={this.onChange}
                                                    style={{width:'90%',display:'flex',margin:'auto',marginTop:'20px'}}
                                                    validators={['required',]}
                                                    errorMessages={['This field is required',]}
                                                    type="number"
                                                />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </div>
                        </div>

                        <div><BuyingThings/></div>

                        <Grid container>
                            <Grid item item xs={12}>
                                <Box className="total_B">
                                    <div className="total_d">
                                        <div>
                                            <h4>Subtotal -  </h4>
                                            <h4>Shipping fee -  </h4>
                                            <h1>TOTAL -  </h1>
                                        </div>
                                        <div className="price_d">
                                            <h4>RS. {total}.00</h4>
                                            <h4>RS. 200.00</h4>
                                            <h1>  RS. {total}.00</h1>
                                        </div>
                                    </div>
                                    <Button type="submit" id="oderBtn">PLACE ODER</Button>
                                </Box>
                            </Grid>
                        </Grid>
                </ValidatorForm>

                </div>

            </Paper>

            {this.state.buyProductDetails.map( rw =>(
                <ul>
                    <li>{rw.buyProductId}</li>
                    <li>{rw.quantity}</li>
                    <li>{rw.price}</li>
                    <li>{rw.shopId}</li>
                </ul>
            ))}
          </div>
        )
    }
}
