import React,{Component} from 'react';
import { Card, CardContent, Grid, FormControl, TextField, Input, FormHelperText, OutlinedInput ,Select ,CardActionArea } from '@material-ui/core';
import { Paper, Typography, AppBar, Toolbar, Button, IconButton ,Divider,Box,Link,CardMedia } from "@material-ui/core";
import { makeStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import Rating from 'material-ui-rating'
import CreateIcon from '@material-ui/icons/Create';
import Close from '@material-ui/icons/Close';
import DeleteIcon from '@material-ui/icons/Delete';
import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';

import Logo from './../../ibaseshopLogo.png'
import ApiService from "../../ApiService";
import './../css/shopDetails.css';



class ShopDetails extends Component {
  constructor(props){
    super(props)
    this.state={
      shops:[],
      deleteShopId:'',
      message:'',

      imagePreviewUrl1:'',
      visible:'none',
      show:false
    }
  }

  handleAdminShopDelete = (e) =>{
    this.setState({
      visible:'block',
      deleteShopId:`${e}`,
      show:true,
    })
  }
  handlecoverHide=(e)=>{
    this.setState({
      visible:'none',
      show:false,
      message:'',
    })
  }



  componentDidMount() {
      this.loadAllShop();
  }

  loadAllShop = () => {
      ApiService.getAllShops()
          .then((res) => {
              this.setState({
                shops: res.data.data,
              });
          });
  }









  conformDeleteProduct = () =>{

      ApiService.deleteShopById(this.state.deleteShopId)
         .then(res => {
             this.setState({message:"Shop deleted successfully.",severity:'success',alertTitle:'Success',show:false,visible:'none'});
             this.setState({shops: this.state.shops.filter(shops => shops.shopId !== this.state.deleteShopId)});
             setTimeout(() => {
                this.setState({visible:'none',message:'',severity:'',alertTitle:''});
             },2500)
         })
         .catch((err) => {
            this.setState({message : 'Shop delete failed.',severity:'error',alertTitle:'Failed',show:false,visible:'none'});
            setTimeout(() => {
                this.setState({visible:'none',show:false,message:'',severity:'',alertTitle:''});
            },2500);
         })

  }



  _handleImageChange1(e) {
    e.preventDefault();

    let reader1 = new FileReader();
    let file1 = e.target.files[0];

    reader1.onloadend = () => {
      this.setState({
        file1: file1,
        imagePreviewUrl1: reader1.result
      });
    }
    reader1.readAsDataURL(file1)
  }


  render(){

    let {imagePreviewUrl1} = this.state;
    const shops=this.state.shops;


      return(
        <div>
            {this.state.message&&(
              <Alert variant="filled" severity={this.state.severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                    <AlertTitle>{this.state.alertTitle}</AlertTitle>
                    {this.state.message}
              </Alert>
            )}
              <div id="shopDetailsMainDiv">

                    {shops.map(shop =>(
                        <Grid container>
                            <Grid item xs={12}>
                              <Card id="shopDiv" key={shop.shopId}>
                                <Grid container>

                                    <Grid item xs={12} sm={12} md={4} style={{ width:'100%',height:'100%'}}>
                                        <div>
                                          {shop.shopLogo&&(
                                            <CardMedia
                                              component="img"
                                              image={shop.shopLogo}
                                              title="Shop Logo"
                                              class="img-responsive"
                                              id="shopPageLogo"
                                            />
                                          )}
                                          {!shop.shopLogo&&(
                                            <img src={Logo} id="shopPageLogo"/>
                                          )}
                                        </div>
                                    </Grid>

                                    <Grid item xs={12} sm={12} md={8}>
                                        <Typography variant="h4" id="shopTitle">
                                          {shop.shopName}
                                          <Rating name="read-only" value={shop.rating} size="small" size="small" readOnly   />
                                        </Typography>
                                        <Button id="shopDetailsDeleteBtn" onClick={() => this.handleAdminShopDelete(shop.shopId)}><DeleteIcon  style={{marginRight:'5px'}}/>Delete</Button>
                                        <Button id="shopDetailsEditeBtn"   href={"/adminShopEdite/"+shop.shopId}><CreateIcon style={{marginRight:'5px'}}/>Edite</Button>
                                    </Grid>

                                </Grid>
                              </Card>
                            </Grid>
                        </Grid>
                      ))
                    }


                    <Box style={{display:this.state.visible,position: 'fixed',top: '0px',left:'0px',width:'100%',height:'100%',zIndex:'2', backgroundColor:'black',opacity:'0.8'}}  onClick={() => this.handlecoverHide()}></Box>
                    {this.state.show&&(
                      <Alert variant="filled" severity="warning" style={{position: 'fixed',top:'300px',width: '550px',zIndex: '3',left: `${window.innerWidth/2-275}px`,color:'white'}}
                            action={
                                <Box style={{marginTop:'50px'}}>
                                  <Button color="inherit" size="small" style={{fontSize:'14px'}} onClick={() => this.handlecoverHide()} >
                                    Cancel
                                  </Button>
                                  <Button color="inherit" size="small" style={{fontSize:'14px'}} onClick={() => this.conformDeleteProduct()} >
                                    Delete
                                  </Button>
                                </Box>
                              }
                      >
                            <AlertTitle>Warning</AlertTitle>
                            Are you sure delete this product?

                      </Alert>
                    )}

              </div>
        </div>
      )
  }
}
export default ShopDetails;
