import React,{Component} from 'react';
import Banner from './images/banner.jpg';
import './css/home.css';
import { Route, Link, BrowserRouter as Router, Switch } from 'react-router-dom';
import Rating from 'material-ui-rating';
import {Grid,Paper,Card,CardContent,Typography,Button, CardActions,CardMedia,CardActionArea,Box} from '@material-ui/core';

import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';

import {DataContext} from '../component/Data'
import './css/ShopSide.css'
import ApiService from "./../ApiService";



class Home extends Component {
  constructor(props){
    super(props)
    this.state={
      products:[],
      pageNo:-1,
      pageSize:4,
      Total_no_of_pages:0,
      disabled:false,
      opacity:1,
    }
  }

  componentDidMount(){
      this.loadProducts()
  }

  loadProducts = () => {
      ApiService.getAllProducts(this.state.pageNo+1,this.state.pageSize)
      .then(res => {
        const products = res.data.data;
        const total_no_of_pages = res.data.Total_no_of_pages;
          this.setState({
              pageNo:this.state.pageNo+1,
              Total_no_of_pages:res.data.Total_no_of_pages,
          })
          {products.map(product =>(
              this.setState(prevState => ({
                  products: [...prevState.products, {
                      "productId":product.productId,
                      "title":product.title,
                      "lastPrice":product.lastPrice,
                      "sellPrice":product.sellPrice,
                      "warranty":product.warranty,
                      "rating":product.rating,
                      "image1":product.image1,
                  }]
              }))
          ))}

          if(total_no_of_pages == this.state.pageNo+1){
            this.setState({
                disabled:true,
                opacity:0.5,
            })
          }

      })
  }



  static contextType = DataContext;

  render(){
    const {addCart,buythins,cartNo} = this.context;
    const products = this.state.products;


    return(
      <div className='Home' style={{backgroundColor:'#d4e3fc'}}>
        <div className='homeImgDiv' style={{display:'flex',margin:'auto',marginTop:'50px'}}>
          <div className='homeImgWar'>
            <img src={Banner} className='homeImg' style={{display:'flex',margin:'auto'}} />

          </div>
        </div>
          <div style={{width:'90%',margin:'auto',marginTop:'50px'}}>
              <Grid container >
                  {products.map(product =>(
                        <Grid item xs={12} sm={6} md={4} lg={3} style={{marginTop:'20px'}}  >
                                <Card className='productCard' key={product.id}  elevation={3}>
                                  <CardActionArea href={'/product/'+product.productId}>
                                    <Box className='showImgDiv'>
                                      <CardMedia
                                        className='showImg'
                                        component="img"
                                        image={product.image1}
                                        title="Contemplative Reptile"
                                        class="img-responsive"
                                        id="showImg"

                                      />
                                    </Box>
                                    <CardContent>
                                      <Typography gutterBottom  className='productTitle'>
                                      {product.title}
                                      </Typography>
                                      <Typography className='offerPrice' variant="h6">
                                        {product.lastPrice}
                                      </Typography>
                                        <Typography className='sellPrice' variant="h6">
                                        {product.sellPrice}
                                        </Typography>
                                        <Typography className='sellPrice' variant="h6">
                                        warranty {product.warranty} (Mo)
                                        </Typography>

                                        <Typography className='offerPrice'>
                                            <Rating name="read-only" value={product.rating} readOnly style={{}} />
                                        </Typography>
                                    </CardContent>
                                  </CardActionArea>
                                  <CardActions >
                                  <Button variant="contained" id="btn" style={{backgroundColor:'#03a9f4',color:'white',margin:'auto'}} onClick={()=> buythins(product.productId)} >
                                  Buy now
                                  </Button>
                                  <Button variant="contained" onClick={()=> addCart(product.productId)} style={{backgroundColor:'#03a9f4',color:'white',margin:'auto'}} ><ShoppingCartIcon/>
                                  Add to cart
                                  </Button>


                                  </CardActions>

                                </Card>
                        </Grid>
                  ))}
                      <Grid item xs={12}>
                        <Paper style={{width:"100%",margin:"auto",marginTop:"40px",height:"60px"}}><Button disabled={this.state.disabled} style={{height:"40px",backgroundColor:"#03a9f4",float:"right",marginRight:"50px",marginTop:"10px",color:"white",fontWeight:"bold",opacity:this.state.opacity}} onClick={()=>this.loadProducts()}>Load more</Button></Paper>
                      </Grid>
              </Grid>
          </div>
      </div>
    );
  }
}

export default Home;
