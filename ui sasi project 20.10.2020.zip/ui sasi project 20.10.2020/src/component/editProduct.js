import React,{Component} from 'react';
import './css/additem.css'

import { AppBar, Typography,CardActionArea,CardMedia,Paper,Divider,Link } from '@material-ui/core';
import { Card, CardContent, Grid, FormControl, TextField, InputLabel, OutlinedInput, Pape, Box,Select, Button,CardActions , TextareaAutosize , FormHelperText } from '@material-ui/core';
import InsertPhotoOutlinedIcon from '@material-ui/icons/InsertPhotoOutlined';
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';

import Alert from '@material-ui/lab/Alert';
import AlertTitle from '@material-ui/lab/AlertTitle';

import AddImg from './images/add.png';

import ApiService from "./../ApiService";



class EditProduct extends Component {
    constructor(props){
      super(props)
      this.state={
        message:'',


        productTitle:'',
        category:'',
        productDescription:'',
        productBrand:'',
        productModel:'',
        lastPrice:'',
        salePrice:'',
        warranty:'',
        rating:'',
        shopId:'',
        stock:'',


        message:'',
        severity:'',
        AlertTitle:'',

        shopOwnerId:'',
        to:'',


        file1: '',
        imagePreviewUrl1: '',

        file2: '',
        imagePreviewUrl2: '',

        file3: '',
        imagePreviewUrl3: '',

        file4: '',
        imagePreviewUrl4: '',

        file5: '',
        imagePreviewUrl5: '',
      }
    }



    componentDidMount() {
        const productId = this.props.match.params.id;
        this.loadProduct(productId);
    }



    loadProduct = (productId) => {
        ApiService.getProductById(productId)
            .then((res) => {
                let product = res.data;
                this.setState({
                    productId:product.productId,
                    productTitle: product.title,
                    category: product.category,
                    productDescription: product.description,
                    productBrand: product.brand,
                    productModel:product.model,
                    lastPrice:product.lastPrice,
                    salePrice:product.sellPrice,
                    warranty:product.warranty,
                    rating:product.rating,
                    shopId:product.shopId,
                    stock:product.stock,

                    file1:product.image1,
                    file2:product.image2,
                    file3:product.image3,
                    file4:product.image4,
                    file5:product.image5,

                    imagePreviewUrl1:product.image1,
                    imagePreviewUrl2:product.image2,
                    imagePreviewUrl3:product.image3,
                    imagePreviewUrl4:product.image4,
                    imagePreviewUrl5:product.image5,

                })

                this.loadShopDetails(product.shopId)
            });
    }


    loadShopDetails = (shopId) => {
        ApiService.getShopById(shopId)
        .then((res) => {
            let shops = res.data;
            this.setState({
                shopOwnerId: shops.ownerId,
            })
            if(shops.ownerId == localStorage.getItem("userId")){
                this.setState({
                  to:"/shop/"+shops.shopId,
                })
            }else {
              this.setState({
                to:"/productDetails",
              })
            }
        })
    }


    onChange = (e) =>{
        this.setState({[e.target.name]:e.target.value,})
    }

  _handleImg1Submit(e) {
    e.preventDefault();
    // TODO: do something with -> this.state.file
    // console.log('handle uploading-', this.state.file1);
  }





  _handleImage1Change1(e) {
    e.preventDefault();

    let reader1 = new FileReader();
    let file1 = e.target.files[0];
    // console.warn("Img data",file1);

    reader1.readAsDataURL(file1)
    reader1.onloadend = (e) => {
      const formData = e.target.result;
      this.setState({
        file1: file1,
        imagePreviewUrl1: formData,
      });

    }

  }



  _handleImage1Change2(e) {
    e.preventDefault();

    let reader2 = new FileReader();
    let file2 = e.target.files[0];

    reader2.onloadend = (e) => {
      const formData = e.target.result;
      this.setState({
        file2: file2,
        imagePreviewUrl2: formData,
      });
    }

    reader2.readAsDataURL(file2)
  }


  _handleImage1Change3(e) {
    e.preventDefault();

    let reader3 = new FileReader();
    let file3 = e.target.files[0];

    reader3.onloadend = (e) => {
      const formData = e.target.result;
      this.setState({
        file3: file3,
        imagePreviewUrl3: formData,
      });
    }

    reader3.readAsDataURL(file3)
  }


  _handleImage1Change4(e) {
    e.preventDefault();

    let reader4 = new FileReader();
    let file4 = e.target.files[0];

    reader4.onloadend = (e) => {
      const formData = e.target.result;
      this.setState({
        file4: file4,
        imagePreviewUrl4: formData
      });
    }

    reader4.readAsDataURL(file4)
  }


  _handleImage1Change5(e) {
    e.preventDefault();

    let reader5 = new FileReader();
    let file5 = e.target.files[0];

    reader5.onloadend = (e) => {
      const formData = e.target.result;
      this.setState({
        file5: file5,
        imagePreviewUrl5: formData,
      });
    }

    reader5.readAsDataURL(file5)
  }


  handleChangCategorye = (e) =>{
    this.setState ({
      category:e.target.value
    });
  }






//update product Details
//update product Details
//update product Details
//update product Details
//update product Details

    updateProduct = () =>{
      // e.preventDefault();
      let product = {
        productId:this.state.productId,
        shopId: this.state.shopId,
        category: this.state.category,
        title: this.state.productTitle,
        description: this.state.productDescription,
        lastPrice: this.state.lastPrice,
        sellPrice: this.state.salePrice,
        warranty: this.state.warranty,
        stock: this.state.stock,
        brand: this.state.productBrand,
        model: this.state.productModel,

        image1:this.state.imagePreviewUrl1,
        image2:this.state.imagePreviewUrl2,
        image3:this.state.imagePreviewUrl3,
        image4:this.state.imagePreviewUrl4,
        image5:this.state.imagePreviewUrl5,
      };


      ApiService.updateProduct(product)
          .then(res => {
              this.setState({message : 'Product update successfully.',severity:"success",AlertTitle:'Success'});

              setTimeout(() => {
                  this.props.history.push(this.state.to);
                  this.setState({message:"",severity:"",AlertTitle:""});
              },2500);
          })
          .catch(error => {
              this.setState({
                  message : 'Product details  Update failed.',
                  severity:"error",
                  AlertTitle:"failed"
                });
                setTimeout(() => {
                    this.setState({message:"",severity:"",AlertTitle:""});
                },2500);
          })
    }





  render(){
    let {imagePreviewUrl1} = this.state;
    let {imagePreviewUrl2} = this.state;
    let {imagePreviewUrl3} = this.state;
    let {imagePreviewUrl4} = this.state;
    let {imagePreviewUrl5} = this.state;




    //this is product brand list const

    const productBrandList = [
      {
        title:"Apple"
      },
      {
        title:"Samsung"
      },
      {
        title:"Realmi"
      },
      {
        title:"OnePlus"
      },
      {
        title:"Vivo"
      },
    ];


    return(
      <div>
          {this.state.message&&(
            <div>
                <Alert variant="filled" severity={this.state.severity} style={{position:"fixed",right:"100px",width:"550px",zIndex:"3",color:"white"}}>
                      <AlertTitle>{this.state.AlertTitle}</AlertTitle>
                      {this.state.message}
                </Alert>
            </div>
          )}

            <Paper id="addProductMainDiv">

              <Typography variant='h4' style={{textAlign:'center'}}>Edit Product</Typography>

                    <ValidatorForm onSubmit={this.updateProduct} >
                          <Grid container>

                                <Grid item xs={12} sm={12} md={6}>
                                  <Paper elevation={3} id="productTitleDiv">
                                        <Typography variant="h5" id="producTitleText">Product Title</Typography>
                                        <TextValidator
                                            Id='productTitleIp'
                                            variant="outlined"
                                            label="Product Title"
                                            onChange={this.onChange}
                                            name="productTitle"
                                            value={this.state.productTitle}
                                            validators={['required']}
                                            errorMessages={['this field is required']}
                                        />
                                  </Paper>
                                </Grid>

                                <Grid item xs={12} sm={12} md={6}>
                                  <Paper elevation={3} id="productCategoryDiv">
                                        <Typography variant="h5" id="producCategoryText">Product Category</Typography>
                                        <FormControl variant="outlined" id='sortSelectIp'>
                                              <InputLabel htmlFor="outlined-category-native-simple">Category</InputLabel>
                                              <Select
                                                    native
                                                    value={this.state.category}
                                                    onChange={this.handleChangCategorye}
                                                    label="Category"
                                                    validators={['required']}
                                                    errorMessages={['this field is required']}

                                              >
                                                    {/*<option value={''}></option>*/}
                                                    <option value={'Mobile And Tablets'}>Mobile And Tablets</option>
                                                    <option value={'Mobile And Tablets Accessories'}>Mobile And Tablets Accessories</option>
                                                    <option value={'Computers & Labtops'}>Computers & Labtops</option>
                                                    <option value={'Computers & Labtops Accessories'}>Computers & Labtops Accessories</option>
                                                    <option value={'Cameras'}>Cameras</option>
                                                    <option value={'Cameras Accessories'}>Cameras Accessories</option>
                                                    <option value={'TV , Video & Audio'}>TV , Video & Audio</option>

                                              </Select>
                                        </FormControl>
                                  </Paper>
                                </Grid>

                                <Grid item xs={12} sm={12} md={6}>
                                  <Paper elevation={3} id="productImageInputDiv">
                                      <Typography variant="h5" id="producImageText">Product Images</Typography>
                                      <div className="previewComponent">
                                        <form onSubmit={(e)=>this._handleImg1Submit(e)}>
                                            <Grid container>
                                                  <Grid xs={12}>
                                                        <div id="imgPreview1">
                                                            <input className="fileInput1"
                                                              type="file"
                                                              accept="image/*"
                                                              onChange={(e)=>this._handleImage1Change1(e)}
                                                             />

                                                             {!imagePreviewUrl1&&(
                                                                <img src={AddImg} className="addItemImg1" />
                                                              )}
                                                                <img src={imagePreviewUrl1} className="addItemImg1" />
                                                        </div>
                                                      {this.state.file1&&(
                                                        <div id="imgPreview2">
                                                            <input className="fileInput2"
                                                              type="file"
                                                              accept="image/*"
                                                              onChange={(e)=>this._handleImage1Change2(e)}
                                                            />

                                                            {!imagePreviewUrl2&&(
                                                               <img src={AddImg} className="addItemImg2" />
                                                             )}

                                                            <img src={imagePreviewUrl2} className="addItemImg2" />
                                                        </div>
                                                      )}

                                                      {this.state.file2&&(
                                                        <div id="imgPreview3">
                                                            <input className="fileInput3"
                                                              type="file"
                                                              accept="image/*"
                                                              onChange={(e)=>this._handleImage1Change3(e)}
                                                            />

                                                            {!imagePreviewUrl3&&(
                                                               <img src={AddImg} className="addItemImg3" />
                                                             )}

                                                            <img src={imagePreviewUrl3} className="addItemImg3" />
                                                        </div>
                                                      )}

                                                      {this.state.file3&&(
                                                        <div id="imgPreview4">
                                                            <input className="fileInput4"
                                                              type="file"
                                                              accept="image/*"
                                                              onChange={(e)=>this._handleImage1Change4(e)}
                                                            />

                                                            {!imagePreviewUrl4&&(
                                                               <img src={AddImg} className="addItemImg4" />
                                                             )}

                                                            <img src={imagePreviewUrl4} className="addItemImg4" />
                                                        </div>
                                                      )}
                                                      {this.state.file4&&(
                                                        <div id="imgPreview5">
                                                            <input className="fileInput5"
                                                              type="file"
                                                              accept="image/*"
                                                              onChange={(e)=>this._handleImage1Change5(e)}
                                                            />

                                                            {!imagePreviewUrl5&&(
                                                               <img src={AddImg} className="addItemImg5" />
                                                             )}

                                                            <img src={imagePreviewUrl5} className="addItemImg5" />
                                                        </div>
                                                      )}
                                                  </Grid>
                                            </Grid>

                                        </form>
                                      </div>
                                  </Paper>
                                </Grid>

                                <Grid item xs={12} sm={12} md={6}>
                                  <Paper elevation={3} id="productDescriptionDiv">
                                        <Typography variant="h5" id="producCategoryText">Product Description</Typography>
                                        <textarea aria-label="minimum height" rowsMin={3} placeholder="Minimum 3 rows" id="productDesId" name="productDescription" value={this.state.productDescription} onChange={this.onChange} />
                                  </Paper>
                                </Grid>

                                <Grid item xs={12} sm={12} md={6}>
                                  <Paper elevation={3} id="productBrandDiv">
                                        <Typography variant="h5" id="producCategoryText">Product Brand</Typography>

                                        <TextValidator
                                            Id='productBrandIP'
                                            variant="outlined"
                                            label="Product Brand"
                                            onChange={this.onChange}
                                            name="productBrand"
                                            value={this.state.productBrand}
                                            validators={['required']}
                                            errorMessages={['this field is required']}
                                        />


                                  </Paper>
                                </Grid>

                                <Grid item xs={12} sm={12} md={6}>
                                  <Paper elevation={3} id="productModelDiv">
                                        <Typography variant="h5" id="producCategoryText">Product Model</Typography>

                                        <TextValidator
                                            Id='productModelIP'
                                            variant="outlined"
                                            label="Product Model"
                                            onChange={this.onChange}
                                            name="productModel"
                                            value={this.state.productModel}
                                            validators={['required']}
                                            errorMessages={['this field is required']}
                                        />

                                  </Paper>
                                </Grid>

                                <Grid item xs={12} sm={12} md={6}>
                                  <Paper elevation={3} id="productLastPriceDiv">
                                        <Typography variant="h5" id="producCategoryText">Stock</Typography>
                                        <TextValidator
                                            Id='productLastPriceIP'
                                            variant="outlined"
                                            label="Stock"
                                            onChange={this.onChange}
                                            name="stock"
                                            value={this.state.stock}
                                            validators={['required']}
                                            errorMessages={['this field is required']}
                                            type="number"
                                        />
                                  </Paper>
                                </Grid>


                                <Grid item xs={12} sm={12} md={6}>
                                  <Paper elevation={3} id="productLastPriceDiv">
                                        <Typography variant="h5" id="producCategoryText">Last Price (Rs) (Optional)</Typography>
                                        <TextValidator
                                            Id='productLastPriceIP'
                                            variant="outlined"
                                            label="Last Price"
                                            onChange={this.onChange}
                                            name="lastPrice"
                                            value={this.state.lastPrice}
                                            validators={['required']}
                                            errorMessages={['this field is required']}
                                            type="number"
                                        />
                                  </Paper>
                                </Grid>


                                <Grid item xs={12} sm={12} md={6}>
                                  <Paper elevation={3} id="productSalePriceDiv">
                                        <Typography variant="h5" id="producCategoryText">Sale Price (Rs) </Typography>


                                        <TextValidator
                                            Id='productSalePriceIP'
                                            variant="outlined"
                                            label="Sale Price"
                                            onChange={this.onChange}
                                            name="salePrice"
                                            value={this.state.salePrice}
                                            validators={['required']}
                                            errorMessages={['this field is required']}
                                            type="number"
                                        />

                                  </Paper>
                                </Grid>


                                <Grid item xs={12} sm={12} md={6}>
                                  <Paper elevation={3} id="productWarrantyDiv">
                                        <Typography variant="h5" id="producCategoryText">Warranty (Months)</Typography>


                                        <TextValidator
                                            Id='productWarrantyIP'
                                            variant="outlined"
                                            label="Warranty"
                                            onChange={this.onChange}
                                            name="warranty"
                                            value={this.state.warranty}
                                            validators={['required']}
                                            errorMessages={['this field is required']}
                                            type="number"
                                        />
                                  </Paper>
                                </Grid>


                          </Grid>
                          <br/><br/>


                          <Box id="addProductDiv">
                              <Button id="addProductBtn" type="submit"    >Update Product</Button>
                          </Box>

                      <br/><br/><br/>
                  </ValidatorForm>

            </Paper>
      </div>
    );
  }
}

export default EditProduct;
